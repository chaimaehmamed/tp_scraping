import requests
from bs4 import BeautifulSoup
from pymongo import MongoClient
from datetime import datetime  

url = "https://www.blogdumoderateur.com/duolingo-ia-concurrence-google/"  

response = requests.get(url)

soup = BeautifulSoup(response.content, "html.parser")

title = soup.find("h1").text.strip()

thumbnail = soup.find("meta", property="og:image")["content"]

category = None
breadcrumb_links = soup.select("div.breadcrumb-section a")
if breadcrumb_links and len(breadcrumb_links) >= 3:
    category = breadcrumb_links[2].text.strip()  # Parfois [3] selon le cas, adapte au besoin

category_tag = soup.find('span', class_='e-link badge badge-blue')  # On suppose que c'est une badge, sinon adapte
subcategory = category_tag.get_text(strip=True) if category_tag else "Sous-catégorie non précisée"
print(f"Sous-catégorie : {subcategory}")

date_tag = soup.find('time')
if date_tag and date_tag.has_attr('datetime'):
    pub_date_raw = date_tag['datetime']
    pub_date = datetime.strptime(pub_date_raw[:10], "%Y-%m-%d").strftime("%Y-%m-%d")
else:
    pub_date = "Date non trouvée"
print(f"Date de publication : {pub_date}")

author_span = soup.find('span', class_='byline')
if author_span:
    author_link = author_span.find('a')
    author = author_link.get_text(strip=True) if author_link else "Auteur non précisé"
else:
    author = "Auteur non précisé"
print(f"Auteur : {author}")

excerpt_tag = soup.find('div', class_='article-hat')  
if excerpt_tag:
    excerpt_p = excerpt_tag.find('p')  
    excerpt = excerpt_p.get_text(strip=True) if excerpt_p else "Aucun résumé disponible"  
else:
    excerpt = "Aucun résumé disponible"  


images = {}
for i, img in enumerate(soup.find_all("img")):
    src = img.get("src")
    desc = img.get("alt") or img.get("title") or ""
    if src:
        images[f"image_{i+1}"] = {
            "url": src,
            "description": desc.strip()
        }


client = MongoClient("mongodb://localhost:27017/")
db = client["blog_moderateur"]
collection = db["articles"]


article = {
    "url": url,
    "title": title,
    "thumbnail": thumbnail,
    "category": category,
    "subcategory": subcategory,
    "summary": excerpt,  
    "date": pub_date,
    "author": author,
    "images": images
}


collection.insert_one(article)
print("✅ Succes : Article inséré portant la catégorie :", category, "et sous-catégorie :", subcategory)
