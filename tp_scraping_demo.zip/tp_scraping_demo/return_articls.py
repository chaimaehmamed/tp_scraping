from pymongo import MongoClient


client = MongoClient("mongodb://localhost:27017/")
db = client["blog_moderateur"]
collection = db["articles"]

def get_articles_by_category_or_subcategory(category=None, subcategory=None):
    query = {}

    
    if category:
        query["category"] = category
    
    
    if subcategory:
        query["subcategory"] = subcategory
    
    
    articles = collection.find(query)
    
    
    articles_list = list(articles)  
    if articles_list:  
        for article in articles_list:
            print(f"Title: {article['title']}")
            print(f"URL: {article['url']}")
            print(f"Category: {article['category']}")
            print(f"Subcategory: {article['subcategory']}")
            print(f"Date: {article['date']}")
            print(f"Author: {article['author']}")
            print(f"Summary: {article['summary']}")
            print(f"Thumbnail: {article['thumbnail']}")
            print("------------")
    else:
        print("Aucun article trouvé pour cette catégorie ou sous-catégorie.")


print("Choisissez la recherche par :")
print("1 - Catégorie")
print("2 - Sous-catégorie")
choice = input("Entrez 1 pour Catégorie ou 2 pour Sous-catégorie : ").strip()

if choice == "1":
    category_input = input("Entrez la catégorie : ").strip()
    if category_input:
        get_articles_by_category_or_subcategory(category=category_input)
    else:
        print("Veuillez entrer une catégorie.")
elif choice == "2":
    subcategory_input = input("Entrez la sous-catégorie : ").strip()
    if subcategory_input:
        get_articles_by_category_or_subcategory(subcategory=subcategory_input)
    else:
        print("Veuillez entrer une sous-catégorie.")
else:
    print("Choix invalide. Veuillez entrer 1 pour Catégorie ou 2 pour Sous-catégorie.")
